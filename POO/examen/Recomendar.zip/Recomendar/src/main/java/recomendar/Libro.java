package recomendar;

public class Libro extends Recomendar {

    public Libro(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }
}
