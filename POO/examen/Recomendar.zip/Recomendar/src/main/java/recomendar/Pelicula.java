package recomendar;

public class Pelicula extends Recomendar {
    public Pelicula(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }
}
