package recomendar;

public class Revista extends Recomendar{
    public Revista(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }
}
