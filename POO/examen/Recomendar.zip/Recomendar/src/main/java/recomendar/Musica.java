package recomendar;

public class Musica extends Recomendar{
    public Musica(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }
}
