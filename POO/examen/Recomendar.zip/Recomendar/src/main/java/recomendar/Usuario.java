package recomendar;

public class Usuario extends Recomendar {
    public Usuario(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }
}
