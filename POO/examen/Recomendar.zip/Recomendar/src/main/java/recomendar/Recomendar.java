package recomendar;

public class Recomendar {
    private String nombre;
    private String autor;
    private String sinopsis;
    private String comentar;
    private String meGusta;


    public Recomendar(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        this.nombre = nombre;
        this.autor = autor;
        this.sinopsis = sinopsis;
        this.comentar = comentar;
        this.meGusta = meGusta;
    }

    public void crear(){

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public String getComentar() {
        return comentar;
    }

    public void setComentar(String comentar) {
        this.comentar = comentar;
    }

    public String getMeGusta() {
        return meGusta;
    }

    public void setMeGusta(String meGusta) {
        this.meGusta = meGusta;
    }
}
