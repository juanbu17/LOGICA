package recomendar;

public class cliente extends Usuario {
    public cliente(String nombre, String autor, String sinopsis, String comentar, String meGusta) {
        super(nombre, autor, sinopsis, comentar, meGusta);
    }

public void MeGusta(){
    System.out.println("");
}
}
