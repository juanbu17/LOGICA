package co.com.tienda.test;

import co.com.tienda.services.ProductoService;

public class TestDelete {

    public static void main(String[] args) {
        ProductoService.eliminarProducto();
    }
}
