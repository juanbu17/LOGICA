package co.com.tienda.main;

import co.com.tienda.View.MenuApp;

public class Main {
    public static void main(String[] args) {
        MenuApp menu=new MenuApp();
        menu.menuProducto();
    }
}
