package co.com.cesde.arkham.entity;

public enum Offer {
    ARRENDAMIENTO,
    VENTA
}
