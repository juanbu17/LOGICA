package co.com.cesde.arkham;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArkhamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArkhamApplication.class, args);
	}

}
