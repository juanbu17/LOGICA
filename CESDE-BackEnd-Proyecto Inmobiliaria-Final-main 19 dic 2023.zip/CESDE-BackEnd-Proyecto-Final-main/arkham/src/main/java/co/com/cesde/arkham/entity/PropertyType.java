package co.com.cesde.arkham.entity;

public enum PropertyType {
    CASA,
    APARTAMENTO,
    APARTAESTUDIO
}
