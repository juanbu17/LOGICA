package co.com.cesde.arkham.entity;

public enum Role {
    ADMINISTRADOR,
    USUARIO
}
