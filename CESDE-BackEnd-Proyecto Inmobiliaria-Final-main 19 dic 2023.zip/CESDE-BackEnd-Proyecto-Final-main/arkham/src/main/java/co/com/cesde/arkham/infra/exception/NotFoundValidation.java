package co.com.cesde.arkham.infra.exception;

public class NotFoundValidation extends Exception {
    public NotFoundValidation(String message) {
        super(message);
    }
}
