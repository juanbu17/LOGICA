package co.com.cesde.arkham.entity;

public enum TokenType {
    BEARER
}
