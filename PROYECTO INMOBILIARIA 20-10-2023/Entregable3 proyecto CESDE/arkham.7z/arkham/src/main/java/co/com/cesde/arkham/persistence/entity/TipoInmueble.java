package co.com.cesde.arkham.persistence.entity;

public enum TipoInmueble {
    CASA,
    APARTAMENTO,
    APARTAESTUDIO
}
