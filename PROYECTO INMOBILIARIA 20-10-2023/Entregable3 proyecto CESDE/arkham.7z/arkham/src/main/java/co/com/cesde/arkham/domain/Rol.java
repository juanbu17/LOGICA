package co.com.cesde.arkham.domain;

public enum Rol {
    ADMINISTRADOR,
    USUARIO
}
