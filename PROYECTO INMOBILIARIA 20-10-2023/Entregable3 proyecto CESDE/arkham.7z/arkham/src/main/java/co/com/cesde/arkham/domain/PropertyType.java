package co.com.cesde.arkham.domain;

public enum PropertyType {
    CASA,
    APARTAMENTO,
    APARTAESTUDIO
}
