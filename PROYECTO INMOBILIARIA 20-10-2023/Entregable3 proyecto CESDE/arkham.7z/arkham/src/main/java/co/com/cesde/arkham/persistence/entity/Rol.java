package co.com.cesde.arkham.persistence.entity;

public enum Rol {
    ADMINISTRADOR,
    USUARIO
}
