package co.com.cesde.arkham.domain;

public enum Offer {
    ARRENDAMIENTO,
    VENTA
}
