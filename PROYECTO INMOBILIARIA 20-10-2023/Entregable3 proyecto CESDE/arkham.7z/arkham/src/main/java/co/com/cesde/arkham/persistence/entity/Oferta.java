package co.com.cesde.arkham.persistence.entity;

public enum Oferta {
    ARRENDAMIENTO,
    VENTA
}
